package kendaraan;
public class Sepeda extends Kendaraan {
	//
	protected int sadel;
	protected int gir;
	//
	public void setSadel(int sadel) {this.sadel = sadel;}
	public void setGir(int gir) {this.gir = gir;}
	public int getSadel() {return this.sadel;}
	public int getGir() {return this.gir;}
}
