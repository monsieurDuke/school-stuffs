package kendaraan;
public class Truk extends Mobil {
	//
	protected int muatan_max;
	//
	public void setMuatanMax(int muatan_max) {this.muatan_max = muatan_max;}
	public int getMuatanMax() {return this.muatan_max;}
}
