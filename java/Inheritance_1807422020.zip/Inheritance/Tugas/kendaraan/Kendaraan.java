package kendaraan;
public class Kendaraan {
	//
	protected int roda;
	protected String warna;
	//
	public void setRoda(int roda) {this.roda = roda;}
	public void setWarna(String warna) {this.warna = warna;}
	public int getRoda() {return this.roda;}
	public String getWarna() {return this.warna;}
}
