public class X {
    Y b = new Y();
    X() {System.out.println("X | 1");}
}
