package Base;
public class Main {
	public static void main(String[] args) {
		Sup s = new Sup();
	}
}
