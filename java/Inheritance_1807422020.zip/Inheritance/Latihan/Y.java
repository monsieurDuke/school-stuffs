public class Y {
    Y() {System.out.println("Y | 2");}
}
