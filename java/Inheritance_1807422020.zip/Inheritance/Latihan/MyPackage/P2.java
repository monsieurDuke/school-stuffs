package MyPackage;
public class P2 extends P1 {
	public static void main(String[] args) {
		P2 p2 = new P2();
		p2.aMethod();
	}
}
