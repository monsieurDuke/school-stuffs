public class Hope {
	public static void main(String[] args) {
		Hope h = new Hope();
	}
	private Hope() {
		for(int i = 0; i < 10; i++) {System.out.print(i+" ");}
	}
}
