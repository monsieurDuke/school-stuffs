import Base.*;
public class Main {
	public static void main(String[] args) {
		Pri p = new Pri();
	}
}
