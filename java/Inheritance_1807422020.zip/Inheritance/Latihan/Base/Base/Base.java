package Base;
public class Base {
	protected void aMethod() {System.out.println("hello wolrd");}
	Base(int i) {System.out.println("hello base const");}
	Base() {
		int i = 100;
		System.out.println(i);
	}
}
