package Base;
public class Sup extends Base {
	public Sup() {super(0);}
	public static void derived() {}
}
