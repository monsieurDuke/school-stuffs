package Base;
public class Pri extends Base {
	int i = 200;
	public Pri() {}
}
