public class Main {
	public static void main(String[] args) {
	//	Lat1 lat1 = new Lat1();
	//	lat1.tochar();
	//	Lat2 lat2 = new Lat2(8);
	//	lat2.factor();
		Lat3 lat3 = new Lat3(8);
		lat3.fibonnaci();
	//	Lat4 lat4 = new Lat4(20);
	//	lat4.sequence();
	}
}
