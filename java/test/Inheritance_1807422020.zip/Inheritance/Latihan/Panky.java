class Panky extends Humpty {
	final void myMethod() {}
}
