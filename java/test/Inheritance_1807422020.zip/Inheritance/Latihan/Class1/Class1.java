package Class1;
import Base.*;
//
public class Class1 extends Base {
	public static void main(String args[]) {
		Base b = new Base();
		b.aMethod();
	}
}

