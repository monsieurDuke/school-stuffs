package MyPackage;
class P1 {
	void aMethod() {System.out.println("hello");}
}
