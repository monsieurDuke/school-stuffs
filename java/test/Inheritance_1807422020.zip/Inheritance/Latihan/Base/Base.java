package Base;
public class Base {
	protected void aMethod() {System.out.println("hello wolrd");}
}
