class Humpty {
	void myMethod() {}
}
